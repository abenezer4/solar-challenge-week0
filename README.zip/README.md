# Clone solar-challenge-week0 from github
# Create virtual enviroment
# RUN pip install -r requirements.txt
